from flask import Flask, render_template, request, redirect, session, flash
from flask_app import app
from flask_app.models.tvshow import Tvshow
from flask_app.models.user import User

@app.route('/tvshow/new')
def tvshow_form():
    if 'user_id' not in session:
        flash('Please Log In.')
        return redirect('/')
    user_id = session['user_id']
    user_data = {"id": user_id}
    user = User.get_one_by_id(user_data)
    return render_template('tvshow_form.html', user=user)

@app.route('/tvshow', methods=['POST'])
def create_tvshow():
    if 'user_id' not in session:
        flash('Please Log In.')
        return redirect('/')
    
    title = request.form['title']
    network = request.form['network']
    comment = request.form['comment']
    release_date = request.form['release_date']

    if len(title) < 3 or len(network) < 3 or len(comment) < 3 or not release_date:
        flash('Title, Network, Comment, and Release Date are required and must be at least 3 characters.')
        return redirect('/tvshow/new')

    user_id = session['user_id']
    user_data = {"id": user_id}
    user = User.get_one_by_id(user_data)

    data = {
        "title": request.form['title'],
        "comment": request.form['comment'],
        "network": request.form['network'],
        "release_date": request.form['release_date'],
        "user_id": user_id,
        "creator_first_name": user.first_name,
        "creator_last_name": user.last_name,
    }

    Tvshow.save(data)
    return redirect('/dashboard')

@app.route('/tvshow/<int:id>/edit')
def edit_page(id):
    if 'user_id' not in session:
        flash('Please Log In.')
        return redirect('/')
    user_id = session['user_id']
    user_data = {"id": user_id}
    user = User.get_one_by_id(user_data)
    data = {
        "id":id
    }
    tvshow = Tvshow.get_one_by_id(data)

    return render_template('edit.html', user=user, tvshow=tvshow)

@app.route('/tvshow/<int:id>/edit',methods=['POST'])
def edit_tvshow(id):
    if 'user_id' not in session:
        flash('Please Log In.')
        return redirect('/')
    
    title = request.form['title']
    network = request.form['network']
    release_date = request.form['release_date']
    comment = request.form['comment']

    if len(title) < 3 or len(network) < 3 or len(comment) < 3:
        flash('Title, Network, and Comment must be at least 3 characters.')
        return redirect(f'/tvshow/{id}/edit')
    
    data = {
        "id":id,
        "title":request.form['title'],
        "comment":request.form['comment'],
        "user_id": session['user_id'],
        "network":request.form['network'],
        "release_date":request.form['release_date']
        # "user_id": request.form['user_id']
    }
    Tvshow.update(data)
    print(request.form)
    return redirect('/dashboard')
    

@app.route('/tvshow/<int:id>/delete')
def delete(id):
    if 'user_id' not in session:
        flash('Please Log In.')
        return redirect('/')
    data = {
        "id":id
    }
    Tvshow.delete(data)
    return redirect('/dashboard')

@app.route('/tvshow/<int:id>')
def show_page(id):
    if 'user_id' not in session:
        flash('Please Log In.')
        return redirect('/')
    user_id = session['user_id']
    user_data = {"id": user_id}
    user = User.get_one_by_id(user_data)
    data = {
        "id":id
    }  
    tvshow = Tvshow.get_one_by_id(data)
    return render_template('show.html', user=user, tvshow=tvshow)

