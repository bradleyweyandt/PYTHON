from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import user
from flask import flash

class Tvshow:
    def __init__(self,data):
        self.id = data['id']
        self.title = data['title']
        self.user_id = data['user_id']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.comment = data['comment']
        self.network = data['network']
        self.release_date = data['release_date']
        self.creator_first_name = data['creator_first_name']
        self.creator_last_name = data['creator_last_name']

    @classmethod
    def save(cls, data):
        query = """
            INSERT INTO tvshows (title, comment, network, release_date, user_id, creator_first_name, creator_last_name)
            VALUES (%(title)s, %(comment)s, %(network)s, %(release_date)s, %(user_id)s, %(creator_first_name)s, %(creator_last_name)s)
        """
        return connectToMySQL('user-exam').query_db(query, data)

    @classmethod
    def get_all_w_creator(cls,data):
        query = """SELECT * FROM tvshows JOIN users ON tvshows.user_id = users.id"""
        results = connectToMySQL('user-exam').query_db(query)

        all_tvshows = []
        
        if results:
            for row in results:
                tvshow = cls(row)

                data = {
                    'id':row['users.id'],
                    'first_name':row['first_name'],
                    'last_name':row['last_name'],
                    'email':row['email'],
                    'password':row['password'],
                    'created_at':row['users.created_at'],
                    'updated_at':row['users.updated_at'],
                }

                tvshow.creator = user.User(data)
                all_tvshows.append(tvshow)
            return all_tvshows
        
    @classmethod
    def get_one_by_id(cls, data):
        query = """
            SELECT tvshows.*, users.first_name as creator_first_name, users.last_name as creator_last_name
            FROM tvshows
            JOIN users ON tvshows.user_id = users.id
            WHERE tvshows.id = %(id)s;
        """
        result = connectToMySQL('user-exam').query_db(query, data)

        if len(result) < 1:
            return None
        print("TV Show Data from Database:", result[0])
        return cls(result[0])
    
    @classmethod
    def update(cls,data):
        query = "UPDATE tvshows SET title = %(title)s, comment = %(comment)s, network = %(network)s, release_date = %(release_date)s WHERE id = %(id)s"
        return connectToMySQL('user-exam').query_db(query,data)
    
    @classmethod
    def delete(cls,data):
        query = "DELETE FROM tvshows WHERE id=%(id)s"
        return connectToMySQL('user-exam').query_db(query,data)
    
    @staticmethod
    def validate_tvshow(tvshow):
        is_valid = True
        if len(tvshow['title']) < 3:
            flash("Title must be at least 3 characters!")
            is_valid = False
        return is_valid