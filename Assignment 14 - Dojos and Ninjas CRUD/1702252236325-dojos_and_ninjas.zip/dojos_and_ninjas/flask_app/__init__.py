from flask import Flask
# creates our flask app
app = Flask(__name__)